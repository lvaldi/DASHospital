from django.apps import AppConfig


class WeeklyscheduleConfig(AppConfig):
    name = 'WeeklySchedule'
